#include"arkread.h"
#include"arkwrite.h"


void escolheFuncao(int funcao, char* arquivo){
    if(funcao == 1){
        lerCSV(arquivo);
    }
    else if (funcao == 2){
        lerBin(arquivo);
    }
    
}

void lerBin(char* arquivo){
    FILE* bin = fopen(arquivo,"rb");
    if(bin == NULL){
        printf(ERRO0);
        exit(0);
    }
    fseek(bin,PAGINA_DISCO,SEEK_CUR); // pula pagina de cabecalho

}

void lerCSV(char* arquivo){
    
    //printf("%s\n",arquivo);
    FILE* CSV = fopen(arquivo,"rb");
    if(CSV == NULL){
        printf(ERRO0);
        exit(0);
    }
        
    FILE* saida = fopen("arquivoTrab1.bin","wb");
    if(saida == NULL){
        printf(ERRO0);
        exit(0);
    }
    //Inicializar cabeçalho
    Cabecalho c = initCabecalho(CSV);
    addCabecalho(c,saida);
    lerArquivo(CSV,saida);
    
    fclose(CSV);
    fclose(saida);
}

void lerArquivo(FILE* CSV, FILE* saida){

    Registro r;
    int bytes = 0;
    char lixo = LIXO;
    int tamanhoRegistroAnterior=0;
    while(1){
        r = lerRegistro(CSV);
        if(r.tamanhoRegistro == 0){
            break;
        }
        if(r.idServidor == 1007123){
            printf("%c TAM:%d :%ld id:%d salario:%lf telefone:%s %d %c Nome:%s %d %c %s\n",r.removido,r.tamanhoRegistro,r.encadeamentoLista,r.idServidor,r.salarioServidor,r.telefoneServidor,r.tamNome,r.tagCampo4,r.nomeServidor,r.tamCargo,r.tagCampo5,r.cargoServidor);    
            printf("%d\n",bytes);
        }
        bytes += r.tamanhoRegistro + 5; // tamanho do registro incluindo os campos removido e indicador de tamanho do registro
        if(bytes <= PAGINA_DISCO){
            addRegistro(r,saida);
            tamanhoRegistroAnterior = r.tamanhoRegistro;
        }
        else{
            fseek(saida,-(tamanhoRegistroAnterior+4),SEEK_CUR); // volta para o indicador de tamanho do registro anterior
            bytes -= (r.tamanhoRegistro+5);
            tamanhoRegistroAnterior += (PAGINA_DISCO-bytes);
            fwrite(&tamanhoRegistroAnterior,sizeof(int),1,saida);
            tamanhoRegistroAnterior -= (PAGINA_DISCO-bytes);
            fseek(saida,(tamanhoRegistroAnterior),SEEK_CUR);
            for(int i=0; i<(PAGINA_DISCO-bytes);i++){
                fwrite(&lixo,sizeof(char),1,saida);
            }
            bytes = r.tamanhoRegistro + 5;
            tamanhoRegistroAnterior = r.tamanhoRegistro;
            addRegistro(r,saida);
        }
    }
    //printf("Acabou©\n");
    rewind(saida);
    char status = '1';
    fwrite(&status,sizeof(char),1,saida);

}

Registro lerRegistro(FILE* CSV){
    Registro r;
    r.tamanhoRegistro = 34; //Bytes do registro independentes dos campos variaveis
    r.removido = '-';
    r.encadeamentoLista = -1;
    r.salarioServidor = -1;
    r.telefoneServidor[0] = '\0';
    for(int i = 1;i<14;i++)
        r.telefoneServidor[i] = LIXO;
    r.tamNome = 0;
    r.tamCargo = 0;
    r.nomeServidor = NULL;
    r.cargoServidor = NULL;
    r.tagCampo4 = 'n';
    r.tagCampo5 = 'c';
    char check;
    fread(&check,sizeof(char),1,CSV);
    if(check == EOF || check == 0)
    {
        r.tamanhoRegistro = 0;
        return r;
    }
    fseek(CSV,-1,SEEK_CUR);
    fscanf(CSV,"%d",&r.idServidor);
    fseek(CSV,1,SEEK_CUR);// pular delimitador
    fread(&check,sizeof(char),1,CSV);
    if(check != ',' && check != '\n'){ //achou campo não nulo
        fseek(CSV,-1,SEEK_CUR); //retorna para ler ultimo byte
        fscanf(CSV,"%lf",&r.salarioServidor);
        fseek(CSV,1,SEEK_CUR);
    }
    fread(&check,sizeof(char),1,CSV);
    if(check != ',' && check != '\n'){ //achou campo não nulo
        fseek(CSV,-1,SEEK_CUR); //retorna para ler ultimo byte
        fread(&r.telefoneServidor,sizeof(char),14,CSV);
        fseek(CSV,1,SEEK_CUR);
    }
    fread(&check,sizeof(char),1,CSV);
    if(check != ',' && check != '\n'){ //achou campo não nulo
        fseek(CSV,-1,SEEK_CUR); //retorna para ler ultimo byte
        char aux;
        int i = 0;
        fread(&aux,sizeof(char),1,CSV);
        while(aux != ',' && aux != '\n'){
            r.nomeServidor = realloc(r.nomeServidor, sizeof(char)*(i+1));    
            r.nomeServidor[i] = aux;
            i++;
            fread(&aux,sizeof(char),1,CSV);
        }
        r.nomeServidor = realloc(r.nomeServidor, sizeof(char)*(i+1));
        r.nomeServidor[i] = '\0';   
        i++;
        r.tamNome = i+1; // add tag
        r.tamanhoRegistro = r.tamanhoRegistro + r.tamNome + 4;// tamanho do nome mais 4 bytes referentes ao indicador de tamanho
    }
    else{
        r.tamNome = 0;
    }
    fread(&check,sizeof(char),1,CSV);
    if(check != ',' && check != '\n'){ //achou campo não nulo
        fseek(CSV,-1,SEEK_CUR); //retorna para ler ultimo byte
        char aux;
        int i = 0;
        fread(&aux,sizeof(char),1,CSV);
        while(aux != ',' && aux != '\n'){
            r.cargoServidor = realloc(r.cargoServidor, sizeof(char)*(i+1));    
            r.cargoServidor[i] = aux;
            i++;
            fread(&aux,sizeof(char),1,CSV);
        }
        r.cargoServidor = realloc(r.cargoServidor, sizeof(char)*(i+1));
        r.cargoServidor[i] = '\0';   
        i++;
        r.tamCargo = i + 1; // add tag
        r.tamanhoRegistro = r.tamanhoRegistro + r.tamCargo + 4;// tamanho do nome mais 4 bytes referentes ao indicador de tamanho 
    }
    else{
        r.tamCargo = 0;
    }
    return r;
}

Cabecalho initCabecalho(FILE* CSV){
    //inicia o cabecalho com dados conhecidos e lidos do arquivo csv
    Cabecalho c;
    c.status = '0';
    c.topolista = -1;
    c.tagCampo1 = 'i';
    c.tagCampo2 = 's';
    c.tagCampo3 = 't';
    c.tagCampo4 = 'n';
    c.tagCampo5 = 'c';
    int i = 0;
    char aux;
    fread(&aux,sizeof(char),1,CSV);
    while(aux != ','){
        c.desCampo1[i] = aux;
        i++;
        fread(&aux,sizeof(char),1,CSV);
    }
    c.desCampo1[i] = '\0';
    i++;
    if(i<39){
        for(i=i;i<40;i++){
            c.desCampo1[i] = LIXO;
        }
    }


    i=0;
    fread(&aux,sizeof(char),1,CSV);
    while(aux != ','){
        c.desCampo2[i] = aux;
        i++;
        fread(&aux,sizeof(char),1,CSV);
    }
    c.desCampo2[i] = '\0';
    i++;
    if(i<39){
        for(i=i;i<40;i++){
            c.desCampo2[i] = LIXO;
        }
    }
    
    i=0;
    fread(&aux,sizeof(char),1,CSV);
    while(aux != ','){
        c.desCampo3[i] = aux;
        i++;
        fread(&aux,sizeof(char),1,CSV);
    }
    c.desCampo3[i] = '\0';
    i++;
    if(i<39){
        for(i=i;i<40;i++){
            c.desCampo3[i] = LIXO;
        }
    }


    i=0;
    fread(&aux,sizeof(char),1,CSV);
    while(aux != ','){
        c.desCampo4[i] = aux;
        i++;
        fread(&aux,sizeof(char),1,CSV);
    }
    c.desCampo4[i] = '\0';
    i++;
    if(i<39){
        for(i=i;i<40;i++){
            c.desCampo4[i] = LIXO;
        }
    }


    i=0;
    fread(&aux,sizeof(char),1,CSV);
    while(aux != '\n' && aux != '\r'){
        c.desCampo5[i] = aux;
        i++;
        fread(&aux,sizeof(char),1,CSV);
    }
    c.desCampo5[i] = '\0';
    i++;
    if(i<39){
        for(i=i;i<40;i++){
            c.desCampo5[i] = LIXO;
        }
    }
    return c;
}





