#ifndef _ARKWRITE_H
#define _ARKWRITE_H

#include<stdio.h>
#include<stdlib.h>
#include"arkread.h"

#define LIXO '@'

void addCabecalho(Cabecalho c, FILE* saida);

void addRegistro(Registro r, FILE* saida);


#endif
