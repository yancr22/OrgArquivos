//Yan Crisóstomo Rohwedder 9779263  

#include"arkread.h"
#include"arkwrite.h"


int main(){

    int funcao;
    char* arquivo;
    scanf("%d %s",&funcao, arquivo);
    //printf("%d\n",funcao);
    escolheFuncao(funcao, arquivo);
    printf("acabou cusao\n");

return 0;
} 