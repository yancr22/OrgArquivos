//Yan Crisóstomo Rohwedder 9779263  

#include"arkread.h"
#include"arkwrite.h"


int main(){

    int funcao;
    char* arquivo = malloc(sizeof(char)*60);
    char* campo = malloc(sizeof(char)*60);
    char* dado = malloc(sizeof(char)*60);
    scanf("%d %60s %60s %60s",&funcao, arquivo, campo, dado);
    printf("%d %s %s %s\n",funcao,arquivo,campo,dado);
    escolheFuncao(funcao, arquivo, campo, dado);
    free(arquivo);
    free(campo);
    free(dado);

return 0;
} 